/*
let numeros = [];
let otrosNumeros= []
let arrayFinal = []

for (let i = 1; i <= 100; i++) {
    let mensaje = `El valor es: ${i}`;
    numeros.push(mensaje);
}

for (let i = 101; i <= 200; i++) {
    let mensaje =`El valor es: ${i}`;
    otrosNumeros.push(mensaje);
}

arrayFinal = [...numeros, ...otrosNumeros]

arrayFinal.forEach((i) => {
    console.log(i);
});
*/

let persona = {
    nombre: "Adonay",
    edad: 18,
    carrera: "software"
}

let persona2 = {
    nombre: "Adonay",
    edad: 17,
    carrera: "software2"
}

let persona3 = {
    nombre: "Adonay",
    edad: 19,
    carrera: "software3"
}

let arrayObjetos = [persona, persona2, persona3];

arrayObjetos.forEach((i) => {
    console.log(i);
});

console.log(arrayObjetos[2].edad);
