let frutas  = ["Bananas", "Manzana", "pera"];

//Accede de manera individual a un valor  de array
console.log(frutas[2])

/*
for(let fruta of fruta){
    console.log(fruta);
}*/

//Agrega un valor a un array
frutas.push("Piña")
//Utiliza el ultimo valor
frutas.pop()
frutas.unshift("Melocoton")
frutas.reverse()
frutas.log(frutas.includes("Melocoton"))
frutas.forEach(i  => console.log(i))
