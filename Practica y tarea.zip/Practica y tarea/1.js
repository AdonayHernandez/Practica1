const usuarios = [
    {"name": "user1", "Edad": 19, "Carrera": "Medicina", "year": 1 },
    {"name": "user2", "Edad": 17, "Carrera": "ingles", "year": 2 },
    {"name": "user3", "Edad": 20, "Carrera": "comonicaciones", "year": 3 },
    {"name": "user4", "Edad": 22, "Carrera": "software", "year": 4 },
    {"name": "user4", "Edad": 21, "Carrera": "software", "year": 5 },
    {"name": "user5", "Edad": 18, "Carrera": "computacion", "year": 6 },
    {"name": "user6", "Edad": 24, "Carrera": "Comunicaciones", "year": 7 },
    {"name": "user7", "Edad": 24, "Carrera": "Comunicaciones", "year": 8 },
    {"name": "user8", "Edad": 24, "Carrera": "Comunicaciones", "year": 9 }
];

const usuariosFilter = usuarios.filter((x) => {
  
    /*  if (x.Carrera == "software") {
        return x;
    }
*/
return x.Carrera == "software"

} )

const usuariosNewFilter = usuarios.filter()

console.log(usuariosFilter)
const usuariosMap = usuarios.map() 

