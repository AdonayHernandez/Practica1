let array1 = [];
let array2 = [];

for (let i = 1; i <= 100; i++) {
array1.push(i);
}

for (let i = 101; i <= 200; i++) {
array2.push(i);
}

let suma = 0;
for (let i = 0; i < array1.length; i++) {
suma += array1[i];
}
for (let i = 0; i < array2.length; i++) {
suma += array2[i];
}
let media = suma / (array1.length + array2.length);

console.log(`La media de ambos arrays es: ${media}`);